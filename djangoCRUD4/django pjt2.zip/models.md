# 멀캠 갤러리 models

## 기본 필드
- 글 번호: `pk`
- 제목: `title`: CharField
- 내용: `content`: TextField
- 유저: `user_id`: CharField
- 유저 비번: `user_pw`: CharField ??
- 작성일: `created_at`: auto_now_add
- 조회수: `view_cnt` ??
- 추천수: `thumb_up`, `thumb_down` ??
- 댓글: `comment` ??